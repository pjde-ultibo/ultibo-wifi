# Zerowi: bare-metal WiFi driver for the Raspberry Pi
See https://iosoft.blog/zerowi for details

Copyright (c) Jeremy P Bentham 2020
