#ifndef FILEIO_ERRNO_H_
# define FILEIO_ERRNO_H_

extern int errno;

#endif /* !FILEIO_ERRNO_H_ */
